//
//  ArvidViewController.swift
//  prijekttest
//
//  Created by Linnea Björck on 2018-04-26.
//  Copyright © 2018 Linnea Björck. All rights reserved.
//

import UIKit

class HostsViewController: UIViewController {
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view.
	}
	
	@IBAction func dissmissPopup(_ sender: UIButton) {
		dismiss(animated: true, completion: nil)
		
	}
	
	
	
	
	
}
